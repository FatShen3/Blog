import Module from './module'
import { assert, forEachValue } from '../util'

export default class ModuleCollection { // module集合, 包括全局顶层module以及它下面的各个命名空间下的module
  constructor (rawRootModule) {
    // register root module (Vuex.Store options)
    this.register([], rawRootModule, false) // 顶层module
  }

  get (path) {
    return path.reduce((module, key) => {
      return module.getChild(key)
    }, this.root)
  }

  getNamespace (path) { // 得到namespace路径
    let module = this.root
    return path.reduce((namespace, key) => {
      module = module.getChild(key)
      return namespace + (module.namespaced ? key + '/' : '')
    }, '')
  }

  update (rawRootModule) { // 更新module，热重载使用
    update([], this.root, rawRootModule)
  }

  register (path, rawModule, runtime = true) { // 注册模块
    if (process.env.NODE_ENV !== 'production') {
      assertRawModule(path, rawModule) // 检查参数
    }

    const newModule = new Module(rawModule, runtime) // 生成module
    if (path.length === 0) { // 最顶层模块(全局命名空间)
      this.root = newModule
    } else { // 有局部命名空间的模块
      const parent = this.get(path.slice(0, -1)) // 父模块
      parent.addChild(path[path.length - 1], newModule) // 为父模块添加子模块
    }

    // register nested modules
    if (rawModule.modules) { // 注册子模块（还有嵌套的情况)
      forEachValue(rawModule.modules, (rawChildModule, key) => {
        this.register(path.concat(key), rawChildModule, runtime)
      })
    }
  }

  unregister (path) { // 移除子模块
    const parent = this.get(path.slice(0, -1))
    const key = path[path.length - 1]
    if (!parent.getChild(key).runtime) return // 一开始就初始化的模块不允许unregister

    parent.removeChild(key)
  }
}

function update (path, targetModule, newModule) {
  if (process.env.NODE_ENV !== 'production') {
    assertRawModule(path, newModule)
  }

  // update target module
  targetModule.update(newModule) // 更新module对象的mutations, actions, getters

  // update nested modules
  if (newModule.modules) { // 递归更新子模块
    for (const key in newModule.modules) {
      if (!targetModule.getChild(key)) { // 新namespace子模块
        if (process.env.NODE_ENV !== 'production') {
          console.warn(
            `[vuex] trying to add a new module '${key}' on hot reloading, ` +
            'manual reload is needed'
          )
        }
        return
      }
      update(
        path.concat(key), // 添加namespace路径
        targetModule.getChild(key), // 旧模块对象
        newModule.modules[key] // 新模块定义
      )
    }
  }
}

const functionAssert = {
  assert: value => typeof value === 'function',
  expected: 'function'
}

const objectAssert = {
  assert: value => typeof value === 'function' ||
    (typeof value === 'object' && typeof value.handler === 'function'),
  expected: 'function or object with "handler" function'
}

const assertTypes = {
  getters: functionAssert,
  mutations: functionAssert,
  actions: objectAssert
}

function assertRawModule (path, rawModule) {
  Object.keys(assertTypes).forEach(key => {
    if (!rawModule[key]) return

    const assertOptions = assertTypes[key]

    forEachValue(rawModule[key], (value, type) => {
      assert(
        assertOptions.assert(value),
        makeAssertionMessage(path, key, type, value, assertOptions.expected)
      )
    })
  })
}

function makeAssertionMessage (path, key, type, value, expected) {
  let buf = `${key} should be ${expected} but "${key}.${type}"`
  if (path.length > 0) {
    buf += ` in module "${path.join('.')}"`
  }
  buf += ` is ${JSON.stringify(value)}.`
  return buf
}
