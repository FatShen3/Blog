import { warn } from '../util/warn'

export default {
  name: 'router-view',
  functional: true,
  props: {
    name: {
      type: String,
      default: 'default'
    }
  },
  render (_, { props, children, parent, data }) { // 函数式组件没有this, 所以把需要的参数直接显示的写出来
    data.routerView = true

    // directly use parent context's createElement() function
    // so that components rendered by router-view can resolve named slots
    const h = parent.$createElement
    const name = props.name
    const route = parent.$route // 触发依赖收集
    const cache = parent._routerViewCache || (parent._routerViewCache = {})

    // determine current view depth, also check to see if the tree
    // has been toggled inactive but kept-alive.
    let depth = 0
    let inactive = false
    while (parent && parent._routerRoot !== parent) { // 判断_routerRoot是因为可能有嵌套的router(看例子nested-router)
      if (parent.$vnode && parent.$vnode.data.routerView) {
        depth++
      }
      if (parent._inactive) {
        inactive = true
      }
      parent = parent.$parent
    }
    data.routerViewDepth = depth

    // render previous view if the tree is inactive and kept-alive
    if (inactive) { // 包裹于keep-alive的情况
      return h(cache[name], data, children)
    }

    const matched = route.matched[depth] // 根据深度来获取匹配的路由
    // render empty node if no matched route
    if (!matched) { // 没有匹配的返回空节点
      cache[name] = null
      return h()
    }

    const component = cache[name] = matched.components[name]

    // attach instance registration hook
    // this will be called in the instance's injected lifecycle hooks
    data.registerRouteInstance = (vm, val) => { // 对应src/install里全局mixin，在beforeCreate和destroy时调用
      // val could be undefined for unregistration
      const current = matched.instances[name]
      if (
        (val && current !== vm) || // beforecreate时, 若router-view不一致
        (!val && current === vm) // destroy时, 若router-view一致
      ) {
        matched.instances[name] = val // 更新
      }
    }

    // also regiseter instance in prepatch hook
    // in case the same component instance is reused across different routes
    ;(data.hook || (data.hook = {})).prepatch = (_, vnode) => { // 在创建component的时候，vue会自动添加prepatch钩子，所以这个钩子会被覆盖啊，不理解了
      matched.instances[name] = vnode.componentInstance
    }

    // resolve props
    data.props = resolveProps(route, matched.props && matched.props[name]) // 利用props来解耦

    return h(component, data, children) // 返回vnode节点
  }
}

function resolveProps (route, config) {
  switch (typeof config) {
    case 'undefined':
      return
    case 'object':
      return config
    case 'function':
      return config(route)
    case 'boolean':
      return config ? route.params : undefined
    default:
      if (process.env.NODE_ENV !== 'production') {
        warn(
          false,
          `props in "${route.path}" is a ${typeof config}, ` +
          `expecting an object, function or boolean.`
        )
      }
  }
}
