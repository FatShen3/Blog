import applyMixin from './mixin'
import devtoolPlugin from './plugins/devtool'
import ModuleCollection from './module/module-collection'
import { forEachValue, isObject, isPromise, assert } from './util'

let Vue // bind on install

export class Store { // 初始化class
  constructor (options = {}) {
    // Auto install if it is not done yet and `window` has `Vue`.
    // To allow users to avoid auto-installation in some cases,
    // this code should be placed here. See #731
    if (!Vue && typeof window !== 'undefined' && window.Vue) { //浏览器环境下自动install
      install(window.Vue)
    }

    if (process.env.NODE_ENV !== 'production') {
      assert(Vue, `must call Vue.use(Vuex) before creating a store instance.`)
      assert(typeof Promise !== 'undefined', `vuex requires a Promise polyfill in this browser.`)
      assert(this instanceof Store, `Store must be called with the new operator.`)
    }

    const {
      plugins = [], // 插件
      strict = false // 严格模式
    } = options

    let {
      state = {}
    } = options
    if (typeof state === 'function') { // 公用模块使用函数来获取数据，就好比VUE组件，否则对象会被共享
      state = state() || {}
    }

    // store internal state
    this._committing = false
    this._actions = Object.create(null)
    this._actionSubscribers = []
    this._mutations = Object.create(null)
    this._wrappedGetters = Object.create(null)
    this._modules = new ModuleCollection(options)
    this._modulesNamespaceMap = Object.create(null)
    this._subscribers = []
    this._watcherVM = new Vue()

    // bind commit and dispatch to self
    const store = this
    const { dispatch, commit } = this
    this.dispatch = function boundDispatch (type, payload) { // 为了保证上下文this，下同
      return dispatch.call(store, type, payload)
    }
    this.commit = function boundCommit (type, payload, options) {
      return commit.call(store, type, payload, options)
    }

    // strict mode
    this.strict = strict // 是否严格模式

    // init root module.
    // this also recursively registers all sub-modules
    // and collects all module getters inside this._wrappedGetters
    installModule(this, state, [], this._modules.root)

    // initialize the store vm, which is responsible for the reactivity
    // (also registers _wrappedGetters as computed properties)
    resetStoreVM(this, state)

    // apply plugins
    plugins.forEach(plugin => plugin(this))

    if (Vue.config.devtools) { // 开启devtool
      devtoolPlugin(this)
    }
  }

  get state () {
    return this._vm._data.$$state
  }

  set state (v) {
    if (process.env.NODE_ENV !== 'production') {
      assert(false, `Use store.replaceState() to explicit replace store state.`)
    }
  }

  commit (_type, _payload, _options) { // commit
    // check object-style commit
    const {
      type,
      payload,
      options
    } = unifyObjectStyle(_type, _payload, _options)

    const mutation = { type, payload }
    const entry = this._mutations[type]
    if (!entry) {
      if (process.env.NODE_ENV !== 'production') {
        console.error(`[vuex] unknown mutation type: ${type}`)
      }
      return
    }
    this._withCommit(() => { // 支持严格模式
      entry.forEach(function commitIterator (handler) {
        handler(payload)
      })
    })
    this._subscribers.forEach(sub => sub(mutation, this.state)) // 发送事件（一般是插件注册，如devtool, logger)

    if (
      process.env.NODE_ENV !== 'production' &&
      options && options.silent
    ) {
      console.warn(
        `[vuex] mutation type: ${type}. Silent option has been removed. ` +
        'Use the filter functionality in the vue-devtools'
      )
    }
  }

  dispatch (_type, _payload) {
    // check object-style dispatch
    const {
      type,
      payload
    } = unifyObjectStyle(_type, _payload)

    const action = { type, payload }
    const entry = this._actions[type]
    if (!entry) {
      if (process.env.NODE_ENV !== 'production') {
        console.error(`[vuex] unknown action type: ${type}`)
      }
      return
    }

    this._actionSubscribers.forEach(sub => sub(action, this.state)) // 发送事件（一般是插件注册，如devtool, logger)

    return entry.length > 1
      ? Promise.all(entry.map(handler => handler(payload))) // 若多于一个，则用Promise.all封装一下
      : entry[0](payload)
  }

  subscribe (fn) { // 注册mutation事件回调
    return genericSubscribe(fn, this._subscribers)
  }

  subscribeAction (fn) { // 注册action回调
    return genericSubscribe(fn, this._actionSubscribers)
  }

  watch (getter, cb, options) { // 等于调用的是vue.$watch, 这里封装下是为了函数接受state和getters作为参数吧
    if (process.env.NODE_ENV !== 'production') {
      assert(typeof getter === 'function', `store.watch only accepts a function.`)
    }
    return this._watcherVM.$watch(() => getter(this.state, this.getters), cb, options)
  }

  replaceState (state) { // 直接替换整个state, devtool调试时用到
    this._withCommit(() => {
      this._vm._data.$$state = state
    })
  }

  registerModule (path, rawModule, options = {}) { // 注册动态模块
    if (typeof path === 'string') path = [path]

    if (process.env.NODE_ENV !== 'production') {
      assert(Array.isArray(path), `module path must be a string or an Array.`)
      assert(path.length > 0, 'cannot register the root module by using registerModule.')
    }

    this._modules.register(path, rawModule)
    installModule(this, this.state, path, this._modules.get(path), options.preserveState) // preserveState允许保留之前的state, 等同于hot模式了
    // reset store to update getters...
    resetStoreVM(this, this.state)
  }

  unregisterModule (path) { // 卸载动态模块
    if (typeof path === 'string') path = [path]

    if (process.env.NODE_ENV !== 'production') {
      assert(Array.isArray(path), `module path must be a string or an Array.`)
    }

    this._modules.unregister(path)
    this._withCommit(() => {
      const parentState = getNestedState(this.state, path.slice(0, -1))
      Vue.delete(parentState, path[path.length - 1])
    })
    resetStore(this)
  }

  hotUpdate (newOptions) { // 支持热重载
    this._modules.update(newOptions)
    resetStore(this, true)
  }

  _withCommit (fn) { // 严格模式的封装
    const committing = this._committing
    this._committing = true
    fn()
    this._committing = committing
  }
}

function genericSubscribe (fn, subs) { // 注册fn到subs(用于mutation, action回调注册)，返回删除函数
  if (subs.indexOf(fn) < 0) {
    subs.push(fn)
  }
  return () => {
    const i = subs.indexOf(fn)
    if (i > -1) {
      subs.splice(i, 1)
    }
  }
}

function resetStore (store, hot) { // 重新初始化store, 可能是卸载一个动态模块、也可能是热重载(hot = true)
  store._actions = Object.create(null)
  store._mutations = Object.create(null)
  store._wrappedGetters = Object.create(null)
  store._modulesNamespaceMap = Object.create(null)
  const state = store.state
  // init all modules
  installModule(store, state, [], store._modules.root, true) // 针对重新加载模块，必然当做hot = true处理, 否则会重新将子模块的state设值到父模块的state下
  // reset vm
  resetStoreVM(store, state, hot) // 重设vm
}

function resetStoreVM (store, state, hot) {
  const oldVm = store._vm

  // bind store public getters
  store.getters = {}
  const wrappedGetters = store._wrappedGetters
  const computed = {}
  forEachValue(wrappedGetters, (fn, key) => {
    // use computed to leverage its lazy-caching mechanism
    computed[key] = () => fn(store)
    Object.defineProperty(store.getters, key, {
      get: () => store._vm[key], // 返回Vue的计算属性值
      enumerable: true // for local getters
    })
  })

  // use a Vue instance to store the state tree
  // suppress warnings just in case the user has added
  // some funky global mixins
  const silent = Vue.config.silent
  Vue.config.silent = true // ...免得用户定义了一些mixin在这里抛出错误到console，城会玩
  store._vm = new Vue({
    data: {
      $$state: state
    },
    computed // 把getters变为计算属性的性质，也就是依赖值改变了getters才会重新计算
  })
  Vue.config.silent = silent

  // enable strict mode for new vm
  if (store.strict) {
    enableStrictMode(store) // 严格模式
  }

  if (oldVm) {
    if (hot) { // 热加载模式
      // dispatch changes in all subscribed watchers
      // to force getter re-evaluation for hot reloading.
      store._withCommit(() => {
        oldVm._data.$$state = null // 触发重新渲染, 其实state是一样的(其内部的observer已经存在，不会重复生成), 主要是getters可能变了，需要重新改变
      })
    }
    Vue.nextTick(() => oldVm.$destroy()) // 摧毁旧vm
  }
}

function installModule (store, rootState, path, module, hot) { // 加载模块(包含子模块)
  const isRoot = !path.length
  const namespace = store._modules.getNamespace(path)

  // register in namespace map
  if (module.namespaced) {
    store._modulesNamespaceMap[namespace] = module
  }

  // set state
  if (!isRoot && !hot) { // 非root, 非hot模式
    const parentState = getNestedState(rootState, path.slice(0, -1)) // 父模块state
    const moduleName = path[path.length - 1] // 模块名
    store._withCommit(() => {
      // 非hot模式下, 旧state被彻底替换
      // hot模式(preserveState也一样)下, state保留
      Vue.set(parentState, moduleName, module.state) // 将子模块state值设置到父模块state下面, 同样变为响应式属性
      // att: 初始化的时候这些对象并不是响应式的，因为还没有生成vue对象来让parentState变为响应式的
      // 所以这里这样写兼容了初始化以及之后重新注册新模块的情况
    })
  }

  const local = module.context = makeLocalContext(store, namespace, path) // 为模块添加context, 包含dispatch、commit等方法

  module.forEachMutation((mutation, key) => { // 遍历mutation, 注册mutation回调
    const namespacedType = namespace + key
    registerMutation(store, namespacedType, mutation, local)
  })

  module.forEachAction((action, key) => { // 遍历action，注册action回调函数
    const type = action.root ? key : namespace + key
    const handler = action.handler || action
    registerAction(store, type, handler, local)
  })

  module.forEachGetter((getter, key) => { // 遍历getter
    const namespacedType = namespace + key
    registerGetter(store, namespacedType, getter, local)
  })

  module.forEachChild((child, key) => { // 加载子模块
    installModule(store, rootState, path.concat(key), child, hot)
  })
}

/**
 * make localized dispatch, commit, getters and state
 * if there is no namespace, just use root ones
 */
function makeLocalContext (store, namespace, path) {
  const noNamespace = namespace === ''

  const local = {
    dispatch: noNamespace ? store.dispatch : (_type, _payload, _options) => { // 子模块才有第三个参数如{root: true}, 下同
      const args = unifyObjectStyle(_type, _payload, _options)
      const { payload, options } = args
      let { type } = args

      if (!options || !options.root) { // 若不是调用root的方法，将type加上namespace
        type = namespace + type
        if (process.env.NODE_ENV !== 'production' && !store._actions[type]) { // 其实dispatch里已经检查了的
          console.error(`[vuex] unknown local action type: ${args.type}, global type: ${type}`)
          return
        }
      }

      return store.dispatch(type, payload)
    },

    commit: noNamespace ? store.commit : (_type, _payload, _options) => {
      const args = unifyObjectStyle(_type, _payload, _options)
      const { payload, options } = args
      let { type } = args

      if (!options || !options.root) {
        type = namespace + type
        if (process.env.NODE_ENV !== 'production' && !store._mutations[type]) {
          console.error(`[vuex] unknown local mutation type: ${args.type}, global type: ${type}`)
          return
        }
      }

      store.commit(type, payload, options)
    }
  }

  // getters and state object must be gotten lazily
  // because they will be changed by vm update
  Object.defineProperties(local, { // local getters和state, 这里之所以定义getter,是因为这些值都依赖于store,然而store是可能变更的，所以每次都重新获取, 并且此时vue还没初始化
    getters: {
      get: noNamespace
        ? () => store.getters
        : () => makeLocalGetters(store, namespace)
    },
    state: {
      get: () => getNestedState(store.state, path)
    }
  })

  return local
}

function makeLocalGetters (store, namespace) { // 获取local getter
  const gettersProxy = {}

  const splitPos = namespace.length
  Object.keys(store.getters).forEach(type => {
    // skip if the target getter is not match this namespace
    if (type.slice(0, splitPos) !== namespace) return // 不是这个namespace下的getter

    // extract local getter type
    const localType = type.slice(splitPos) // 去除namespace后的type, 如moduleA/getter变为getter

    // Add a port to the getters proxy.
    // Define as getter property because
    // we do not want to evaluate the getters in this time.
    Object.defineProperty(gettersProxy, localType, { // 以此实现namespace的相对路径调用, 并且延后获取值，因为此时store的vue还没有初始化
      get: () => store.getters[type],
      enumerable: true
    })
  })

  return gettersProxy
}

function registerMutation (store, type, handler, local) {
  const entry = store._mutations[type] || (store._mutations[type] = [])
  entry.push(function wrappedMutationHandler (payload) {
    handler.call(store, local.state, payload)
  })
}

function registerAction (store, type, handler, local) {
  const entry = store._actions[type] || (store._actions[type] = [])
  entry.push(function wrappedActionHandler (payload, cb) {
    let res = handler.call(store, {
      dispatch: local.dispatch,
      commit: local.commit,
      getters: local.getters,
      state: local.state,
      rootGetters: store.getters,
      rootState: store.state
    }, payload, cb)
    if (!isPromise(res)) { // 如果不是promise, 返回一个resolve的promise
      res = Promise.resolve(res)
    }
    if (store._devtoolHook) { // devtool情况下
      return res.catch(err => { 
        store._devtoolHook.emit('vuex:error', err) // 如果promise rejected, 给devtool传递错误信息
        throw err
      }) // 返回promise, 状态由res决定(或者是res内又返回了promise),详细可查看Promise.prototype.then
    } else {
      return res // 直接返回
    }
  })
}

function registerGetter (store, type, rawGetter, local) {
  if (store._wrappedGetters[type]) {
    if (process.env.NODE_ENV !== 'production') {
      console.error(`[vuex] duplicate getter key: ${type}`)
    }
    return
  }
  store._wrappedGetters[type] = function wrappedGetter (store) {
    return rawGetter(
      local.state, // local state
      local.getters, // local getters
      store.state, // root state
      store.getters // root getters
    )
  }
}

function enableStrictMode (store) { // 严格模式实现
  // 任何修改state值的行为, 必须是被store._withCommit方法包裹的(内部使用, 如commit方法)
  // _withCommit设置了store._committing为true, 在执行完方法后再变回false
  // 应用自行修改state值的时候store._committing为false触发警告
  store._vm.$watch(function () { return this._data.$$state }, () => { 
    if (process.env.NODE_ENV !== 'production') {
      assert(store._committing, `Do not mutate vuex store state outside mutation handlers.`)
    }
  }, { deep: true, sync: true }) // sync来保证watcher立即执行回调，而不是放入queue中异步执行(参看vue实现), 这样保证了对state值改变的实时监控
}

function getNestedState (state, path) { // 得到子state, 同样根据命名空间路径
  return path.length
    ? path.reduce((state, key) => state[key], state)
    : state
}

function unifyObjectStyle (type, payload, options) {
  if (isObject(type) && type.type) { // type为对象的情况
    options = payload
    payload = type
    type = type.type
  }

  if (process.env.NODE_ENV !== 'production') {
    assert(typeof type === 'string', `Expects string as the type, but found ${typeof type}.`)
  }

  return { type, payload, options }
}

export function install (_Vue) {
  if (Vue && _Vue === Vue) {
    if (process.env.NODE_ENV !== 'production') {
      console.error(
        '[vuex] already installed. Vue.use(Vuex) should be called only once.'
      )
    }
    return
  }
  Vue = _Vue
  applyMixin(Vue)
}
