const devtoolHook =
  typeof window !== 'undefined' &&
  window.__VUE_DEVTOOLS_GLOBAL_HOOK__

export default function devtoolPlugin (store) {
  if (!devtoolHook) return

  store._devtoolHook = devtoolHook

  devtoolHook.emit('vuex:init', store)

  devtoolHook.on('vuex:travel-to-state', targetState => { // 跳转到某个状态快照
    store.replaceState(targetState)
  })

  store.subscribe((mutation, state) => { // 将mutation修改后对应的状态快照传递给devtools
    devtoolHook.emit('vuex:mutation', mutation, state)
  })
}
