import { forEachValue } from '../util'

export default class Module {
  constructor (rawModule, runtime) {
    this.runtime = runtime
    this._children = Object.create(null)
    this._rawModule = rawModule
    const rawState = rawModule.state
    this.state = (typeof rawState === 'function' ? rawState() : rawState) || {} // state为function的情况是支持模块重用
  }

  get namespaced () { // Module实例的namespaced getter
    return !!this._rawModule.namespaced
  }

  addChild (key, module) { // 添加子模块
    this._children[key] = module
  }

  removeChild (key) { // 移除子模块
    delete this._children[key]
  }

  getChild (key) { // 获取子模块
    return this._children[key]
  }

  update (rawModule) { // 更新module(热重载)
    this._rawModule.namespaced = rawModule.namespaced
    if (rawModule.actions) {
      this._rawModule.actions = rawModule.actions
    }
    if (rawModule.mutations) {
      this._rawModule.mutations = rawModule.mutations
    }
    if (rawModule.getters) {
      this._rawModule.getters = rawModule.getters
    }
  }

  // 下面是一系列封装，针对子模块、gettes、actions、mutations遍历然后调用回调函数

  forEachChild (fn) {
    forEachValue(this._children, fn)
  }

  forEachGetter (fn) {
    if (this._rawModule.getters) {
      forEachValue(this._rawModule.getters, fn)
    }
  }

  forEachAction (fn) {
    if (this._rawModule.actions) {
      forEachValue(this._rawModule.actions, fn)
    }
  }

  forEachMutation (fn) {
    if (this._rawModule.mutations) {
      forEachValue(this._rawModule.mutations, fn)
    }
  }
}
