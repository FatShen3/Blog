import View from './components/view'
import Link from './components/link'

export let _Vue // ...这样来把Vue给别的模块使用

export function install (Vue) {
  if (install.installed) return // 避免重复Vue.use
  install.installed = true

  _Vue = Vue

  const isDef = v => v !== undefined

  const registerInstance = (vm, callVal) => {
    let i = vm.$options._parentVnode
    if (isDef(i) && isDef(i = i.data) && isDef(i = i.registerRouteInstance)) {
      i(vm, callVal)
    }
  }

  Vue.mixin({ // 全局mixin
    beforeCreate () {
      if (isDef(this.$options.router)) { // 有router, 则是根节点
        this._routerRoot = this // 根节点vue对象
        this._router = this.$options.router
        this._router.init(this) // 初始化router, 展示第一个页面
        // 在router-view、router-link render时，其dep加入render watcher, 形成依赖关系
        // 换句话说，改变根节点的_route指向新的route, 将引发重新render
        Vue.util.defineReactive(this, '_route', this._router.history.current)         
      } else {
        this._routerRoot = (this.$parent && this.$parent._routerRoot) || this
      }
      registerInstance(this, this) // matched添加vue instance
    },
    destroyed () {
      registerInstance(this) 
    }
  })

  Object.defineProperty(Vue.prototype, '$router', { // 所有vue对象都可以访问到$router
    get () { return this._routerRoot._router }
  })

  Object.defineProperty(Vue.prototype, '$route', { // 所有vue对象都可以访问到当前$route
    get () { return this._routerRoot._route }
  })

  Vue.component('router-view', View) // vue-router提供的两个组件
  Vue.component('router-link', Link)

  const strats = Vue.config.optionMergeStrategies // 自定义选项融合策略, 同created策略(child策略后于parent策略执行)
  // use the same hook merging strategy for route hooks
  strats.beforeRouteEnter = strats.beforeRouteLeave = strats.beforeRouteUpdate = strats.created
}
